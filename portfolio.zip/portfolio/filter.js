$(function()
{
$("#filter li").click(function()
{
	var category = $(this).html();

	console.log(category);
});
});